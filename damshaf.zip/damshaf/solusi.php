<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagnosa Gejala</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   
</head>
<body>
    <?php
    include("koneksi.php");
    $duri = $_GET['solusi'];
    $data = $koneksi->query("SELECT * FROM solusi");
    foreach ($data as $d) {
      if (strtolower($d['nama_penyakit']) == strtolower($duri)) { ?>
        <center>
                <img src="gambar/<?= str_replace(' ','',$d['foto']) ?>" width="200" alt="">
            </center>
    <?php } } ?>
    
    <?php
    // include('koneksi.php');
        $isi_solusi = $koneksi->query("SELECT * FROM solusi WHERE nama_penyakit='$duri'");
    ?>
    <div class="container p-0" style="margin:0 center;max-width:567px;">
        <center>
        <h4 class="mt-5">
            Solusi Penyakit <?= $duri; ?>
        </h4>
        <br>
        <p><?php foreach ($isi_solusi as $isi) {
            echo $isi['solusi'];
        } ?></p>
        </center>

        
  </div>
</body>
</html>