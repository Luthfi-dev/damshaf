<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Data</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>
<body class="container">
<div class="row">
    <div class="col-md-4">
        <br>
        <a href="tambah_data_penyakit.php" class="btn btn-danger">Buat baru data</a>
    </div>
    <div class="col-md-4">
        <br>
        <a href="editjson.php" class="btn btn-warning">Edit data</a>
    </div>
    <div class="col-md-4">
        <br>
        <a href="buatjson.php" class="btn btn-success">Reset Ke Data Awal</a>
    </div>
</div>
<br><br><br>
<?php

$data = file_get_contents("data.json");
// Mengubah kembali ke format JSON yang rapi dengan opsi JSON_PRETTY_PRINT
$prettyJson = preg_replace('/(,|{)/', "$1\n", $data);
$replace_data = str_replace("{","",$prettyJson);

echo '<pre>' . htmlspecialchars($replace_data) . '</pre>';
    
?>

    
</body>
</html>
