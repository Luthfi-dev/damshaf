<?php
// include "koneksi.php";
// $data = $koneksi->query("SELECT * FROM tb_penyakit WHERE id_penyakit='1'");
// $data = $data->fetch_assoc();
// $d = json_encode($data['arr']);
// $decodedString = str_replace("\\\\n", "", $d);
$file = 'data.json';
$data = file_get_contents($file);
$jsonData = json_decode($data, true);

// var_dump($jsonData);

    // Dataset dengan bobot gejala dan penyakit
    $dataset = $jsonData;

    // var_dump($dataset);
    // Dataset dengan bobot gejala dan penyakit
    // $dataset = [
    //   'scabies' => [
    //     'rasa gatal' => 0.8,
    //     'bekas galian' => 0.6,
    //     'muncul benjolan' => 0.4,
    //     'galian timbul' => 0.2
    //   ],
    //   'tinea' => [
    //     'keadaan kulit mengelupas' => 0.7,
    //     'kulit pecah pecah' => 0.5,
    //     'rasa gatal' => 0.9,
    //     'tampak berwarna merah' => 0.3,
    //     'kulit bersisik' => 0.6
    //   ],
    //   'candidiasis' => [
    //     'muncul gelembung' => 0.3,
    //     'kulit bersisik' => 0.4,
    //     'tampak berwarna merah' => 0.5,
    //     'rasa gatal' => 0.7
    //   ],
    //   'varicella' => [
    //     'rasa gatal' => 0.9,
    //     'tampak berwarna merah' => 0.8,
    //     'muncul gelembung' => 0.6,
    //     'kulit melepuh' => 0.5,
    //     'nyeri disekitar' => 0.2
    //   ],
    //   'herpes zoster' => [
    //     'rasa gatal' => 0.7,
    //     'kulit melepuh' => 0.6,
    //     'muncul gelembung' => 0.8,
    //     'muncul ruam' => 0.4,
    //     'tampak berwarna merah' => 0.9,
    //     'demam' => 0.3
    //   ],
    //   'eczema' => [
    //     'keadaan kulit mengelupas' => 0.6,
    //     'tampak berwarna merah' => 0.8,
    //     'kulit bersisik' => 0.5,
    //     'kulit terasa kering' => 0.7
    //   ],
    //   'dermatitis' => [
    //     'rasa gatal' => 0.7,
    //     'tampak berwarna merah' => 0.9,
    //     'kulit terasa kering' => 0.8,
    //     'muncul benjolan' => 0.4,
    //     'kulit bersisik' => 0.3
    //   ],
    //   'impetigo' => [
    //     'kulit melepuh' => 0.5,
    //     'tampak berwarna merah' => 0.7,
    //     'kulit bernanah' => 0.6,
    //     'bengkak diarea' => 0.4,
    //     'demam' => 0.2
    //   ],
    //   'insect bite' => [
    //     'rasa gatal' => 0.9,
    //     'muncul benjolan' => 0.7,
    //     'sensasi kesemutan' => 0.3,
    //     'tampak berwarna merah' => 0.5
    //   ],
    //   'herpes simplex' => [
    //     'tampak berwarna merah' => 0.6,
    //     'rasa gatal' => 0.8,
    //     'muncul gelembung' => 0.7,
    //     'koreng diarea luka' => 0.4
    //   ]
    // ];

    // if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //   $selectedGejala = $_POST['gejala'];
    // get gejala yang di pilih user
    $duri = $_GET['plh'];
    $gejalaUser = json_decode($duri);
    // $json = json_encode($gejalaUser); // Mengubah array menjadi format JSON
// $result = substr($json, 1, -1); // Menghapus tanda kurung siku di awal dan akhir string
// $pilihan = "[".$result."]"; // Menampilkan hasil dengan menambahkan tanda kurung siku

$selectedGejala = $gejalaUser;

      $totalBobot = [];
      $label = [];

      $l=0;
      foreach ($dataset as $penyakit => $gejalaBobot) {
        $penyakitBobot = 2;
        $label[$l] = $penyakit;
        $l++;

        foreach ($gejalaBobot as $gejala => $bobot) {

          if (in_array($gejala, $selectedGejala)) {
            $penyakitBobot *= $bobot;
          } else {
            $penyakitBobot *= (1 - $bobot);
          }

        }

        $totalBobot[$penyakit] = $penyakitBobot;
      }

      // Menghitung nilai keyakinan
      $totalBobotSum = array_sum($totalBobot);
      $keyakinan = [];

      // $j = 0;
      foreach ($totalBobot as $penyakit => $bobot) {
        $keyakinan[$penyakit] = $bobot / $totalBobotSum;
        // $j++;
      }

      // Menampilkan hasil prediksi
      arsort($keyakinan);
      $penyakitTerprediksi = key($keyakinan);
      $nilaiKeyakinan = current($keyakinan);

    ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" />
  <title>Prediksi Penyakit</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .fade-in {
      animation: fadeIn 1s forwards;
      opacity: 0;
    }
    
    .fade-out {
      animation: fadeOut 1s forwards;
      opacity: 1;
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
    
    @keyframes fadeOut {
      from {
        opacity: 1;
      }
      to {
        opacity: 0;
      }
    }

    /* loading */
        .loading-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    #loading {
      width: 100px;
      height: 100px;
      border: 10px solid #f3f3f3;
      border-top: 10px solid #3498db;
      border-radius: 50%;
      animation: spin 5s linear infinite;
    }

    .loading-text {
      margin-top: 10px;
      text-align: center;
      font-weight: bold;
      font-size: 24px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  
  <div class="container" style="max-width:567px">
      <div class="loading-container" style="margin-top:-250px">
        <div id="loading" class="loading-circle"></div>
        <div class="loading-text" id="countdown" style="margin-left:-70px">0</div>%
        <div style="margin-left:-80px;margin-bottom:-150px">Tingkat keyakinan...</div>
        <div style="margin-left:-170px;margin-bottom:-200px">
        <!-- <img src="gambar/64a74e3e699792.52403683.jpg" alt=""> -->
            <h5><i>Penyakit : </i><?= $penyakitTerprediksi ?></h5>
        </div>
        <!-- cek ke database penyakit -->
    <?php
    include("koneksi.php");
    $data = $koneksi->query("SELECT * FROM solusi");
    foreach ($data as $d) {
      if (strtolower($d['nama_penyakit']) == strtolower($penyakitTerprediksi)) { ?>
        <!-- <center> -->
          <div style="position:absolute;top:35%">
                <img src="gambar/<?= str_replace(' ','',$d['foto']) ?>" width="200" alt="">
            <!-- </center> -->
            <a href="solusi.php?solusi=<?= $penyakitTerprediksi; ?>" class="btn btn-primary" style="margin-left:-160px;margin-bottom:-270px">
            Lihat Solusi ->
        </a>
          </div>

    <?php } } ?>
    </div>

<div style="margin-top:100px">
<h5>History Proses</h5>
    <?php
      $i0 = 0;
      $ar_gejala = [];
      $ar_penyakit = [];
      foreach ($dataset as $penyakit => $gejalaBobot) {
        $penyakitBobot = 2;
// echo "<br><br>GEJALA (".$i0.")========<br>";
// var_dump($gejalaBobot);
        $i1 = 0;
        $huruf = ["G1","G2","G3","G4","G5","G6","G7","G8",];
        $huruf2 = ["P1","P2","P3","P4","P5","P6","P7","P8",];
        foreach ($gejalaBobot as $gejala => $bobot) {
// echo "<br>BOBOT GEJALA=====<br>";
$ar_gejala[$i1] = $huruf[$i1]." = ".$bobot;
          if (in_array($gejala, $selectedGejala)) {
            $penyakitBobot *= $bobot;
          } else {
            $penyakitBobot *= (1 - $bobot);
          }
          // echo "<br>----<br><br>BOBOT PENYAKIT----<br>";
          $ar_penyakit[$i1] = $huruf2[$i1]." = ".$penyakitBobot;
        $i1++;

        }

        $totalBobot[$penyakit] = $penyakitBobot;
        $i0++;
      }

      echo "<br> BOBOT PENYAKIT <br>";
      for ($i=0; $i < count($ar_penyakit); $i++) { 
          echo $ar_penyakit[$i]."<br>";
      }
      echo "<br> BOBOT GEJALA <br>";
      for ($i=0; $i < count($ar_gejala); $i++) { 
          echo $ar_gejala[$i]."<br>";
      }
      // var_dump();

        echo "<br>=======TOTAL BOBOT SUM========<br>";
        echo "<br><i>Σ(bobot_penyakit) = bobot_penyakit1 + bobot_penyakit2 + bobot_penyakit3 + ... + bobot_penyakitn</i><br>";
        echo "<br><b>SUM PENYAKIT</b> = ".$totalBobotSum;

      foreach ($totalBobot as $penyakit => $bobot) {
        $keyakinan[$penyakit] = ($bobot / $totalBobotSum)*100;
      }

        echo "<br><br>=======TOTAL BOBOT KEYAKINAN========<br>";
        echo "<br>Bobot Keyakinan = (Bobot Penyakit / Total Bobot Sum) x 100%<br>";
        for ($k=0; $k < count($label); $k++) { 
          echo "<br><b>".$label[$k]." = </b>".$bobot."/".$totalBobotSum." = ".$keyakinan[$label[$k]]."<br>";
        }
        // var_dump($label);
        // print_r($keyakinan);
        // foreach ($nilaiKeyakinan as $k) {
        //   echo $k;
        // }
      echo '<br><h4>Hasil Prediksi:</h4>';
      echo '<p>Pasien kemungkinan mengalami penyakit <strong>' . $penyakitTerprediksi . '</strong> dengan tingkat keyakinan ' . $nilaiKeyakinan . '</p>';
    // }
    $persentase =$nilaiKeyakinan*100;
    ?>
</div>

  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    console.log(<?= $persentase; ?>)
     // Menghitung angka dari 0 hingga 50 dalam 5 detik
    let counter = 0;
    const target = <?= round($persentase); ?>;
    const duration = 5;
    const step = target / (duration * 1000 / 10);

    const countdown = document.getElementById("countdown");
    const loading = document.getElementById("loading");

    const interval = setInterval(() => {
      counter += step;
      countdown.textContent = Math.round(counter);

      if (counter >= target) {
        clearInterval(interval);
        countdown.textContent = target;
      }
    }, 10);

    
// Kode yang akan dieksekusi setelah 5 detik
function kodeBaru() {
      loading.style.borderTop = "10px solid #f3f3f3";

}

// Menunda eksekusi kode baru selama 5 detik (5000 milidetik)
setTimeout(kodeBaru, 7000);

  </script>
</body>
</html>
