<?php
session_start();
  if (!$_SESSION) {
    header("Location: ../login.php");
        exit;
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>
<body>
    <div class="container">
        <center>
            <h3>Pilih Aksi di bawah ini!</h3>
            <a href="../solusi" class="btn btn-primary"> >>> Data Solusi <<< </a>
            <br><br>
            <a href="../data_penyakit.php" class="btn btn-primary"> >>> Data Penyakit dan Bobot <<< </a>
        </center>
    </div>
</body>
</html>