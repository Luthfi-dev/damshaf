<?php
include('koneksi.php');
$data = $koneksi->query("SELECT * FROM gejala");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Display Questions</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <style>
    .question-container {
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
      text-align: center;
      opacity: 1;
      transition: opacity 0.5s ease-in-out;
    }
    .fade-out {
      opacity: 0;
    }
    .p-0 {padding:0}
  </style>
</head>
<body>
  <div class="container" style="margin-top: 100px;max-width:567px">
    <h6>Apakah terdapat gejala berikut, pilih sesuai gejala yang dialami</h6>
    <!-- <form id="myForm" action="d.php" method="GET"> -->
        <div id="questions-container">
        </div>
        <!-- <button>submit</button> -->
    <!-- </form> -->
    <!-- <button id="next-btn" class="btn btn-primary">Next</button> -->
    <span id="next-btn" onclick="submitGejala()" class='btn btn-light mb-2 mr-2 w-100 shadow' style='text-align:left'>Tidak ada pilihan di atas</span>
    <button id="next-btn2" class="btn btn-primary" onclick="submitGejala()">Lanjut</button>
</div>
        <?php
        $isi_gejala = "";
        $i = 1;
        $jml_data = $data->num_rows;
         foreach ($data as $d) {
            if ($i < $jml_data) {
                $isi_gejala .= "'" . $d['nama_gejala'] . "', ";
            } else {
                $isi_gejala .= "'" . $d['nama_gejala'] . "'";
            }
        $i++;
        }?>
  <script>

    // Daftar pertanyaan
    var questions = [<?= $isi_gejala; ?>];
console.log(questions);
    // mengambil value dari pilhan
            var selectedGejala = [];
    function submitGejala() {
            $("input[name='gejala[]']:checked").each(function() {
                selectedGejala.push($(this).val());
            });
            console.log(selectedGejala);
            if (selectedGejala.length > 0) {
                // $.ajax({
                //     type: "POST",
                //     url: "backend.php",
                //     data: { selectedGejala: selectedGejala },
                //     dataType: "json",
                //     success: function(data) {
                //         showResult(data);
                //     }
                // });
                console.log("oke");
            }
        }

    console.log(selectedGejala);
    var currentIndex = 0;
    var questionsPerPage = 5;

    // +++++++++++++++++++++
    // Menampilkan pertanyaan secara acak
function shuffleQuestions() {
  questions = shuffle(questions); // Panggil fungsi shuffle untuk mengacak urutan pertanyaan
}

// Mengacak urutan elemen dalam array
function shuffle(array) {
  var currentIndex = array.length;
  var temporaryValue, randomIndex;

  while (0 !== currentIndex) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

// Memuat pertanyaan pertama kali (setelah diacak)
shuffleQuestions();
displayQuestions();
    // +++++++++++++++++

    // Menampilkan pertanyaan
    function displayQuestions() {
      var questionsContainer = $("#questions-container");
      questionsContainer.empty();

      for (var i = currentIndex; i < currentIndex + questionsPerPage; i++) {
        if (i >= questions.length) {
          break;
        }

            var question = questions[i];
            var questionElement = $("<div>").text(question);
            console.log(questionElement);
            console.log(question);
            questionsContainer.append("<button class='btn btn-light mb-2 mr-2 w-100 shadow' style='text-align:left'><input class='mr-3' type='checkbox' name='gejala[]' value='"+question+"'/>"+question+"</button><br>");

      }
    }

    // Menampilkan pertanyaan selanjutnya
    function showNextQuestions() {
      currentIndex += questionsPerPage; 
        displayQuestions();
            
    console.log(currentIndex,questionsPerPage)
        if (currentIndex >= 20) {
            // ekskripsi array agar saat di get tidak hilang tanda petik
            var encodedData = encodeURIComponent(JSON.stringify(selectedGejala));
            window.location.href="diagnosa.php?plh="+encodedData;
        }
    }


    // Memuat pertanyaan pertama kali
    displayQuestions();

    // Mengikat event click pada tombol Next
    $("#next-btn").click(function() {
            showNextQuestions();
    });
    $("#next-btn2").click(function() {
            showNextQuestions();
    });
  </script>
</body>
</html>
