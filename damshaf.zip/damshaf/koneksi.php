<?php

$koneksi = new mysqli("localhost","root","","d_virza");

                // Periksa koneksi
                if (mysqli_connect_errno()) {
                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    exit();
                }
