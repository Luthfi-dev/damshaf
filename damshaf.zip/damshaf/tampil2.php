<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampilan Data Gejala</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        /* Tampilan seperti aplikasi mobile */
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
        .table {
            background-color: #ffffff;
            border-radius: 10px;
        }
        .table th, .table td {
            border-top: none;
        }
        .dropdown-menu {
            min-width: 100px;
        }
        .dropdown-menu .dropdown-item {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tampilan Data Gejala</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Gejala</th>
                    <th>Bobot</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Koneksi ke database
                $koneksi = mysqli_connect("localhost", "root", "", "d_virza");

                // Periksa koneksi
                if (mysqli_connect_errno()) {
                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    exit();
                }

                // Query untuk mendapatkan data gejala
                $query = "SELECT * FROM gejala";
                $result = mysqli_query($koneksi, $query);

                // Loop melalui setiap baris data
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['nama_gejala'] . "</td>";
                    echo "<td>" . $row['bobot'] . "</td>";
                    echo "<td>
                            <div class='dropdown'>
                                <button class='btn btn-light dropdown-toggle' type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                    <i class='fas fa-ellipsis-v'></i>
                                </button>
                                <div class='dropdown-menu dropdown-menu-right' aria-labelledby='dropdownMenuButton'>
                                    <a class='dropdown-item' href='#'>Edit</a>
                                    <a class='dropdown-item' href='#'>Hapus</a>
                                </div>
                            </div>
                        </td>";
                    echo "</tr>";
                }

                // Menutup koneksi database
                mysqli_close($koneksi);
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
