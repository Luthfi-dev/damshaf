-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2023 at 05:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `d_virza`
--

-- --------------------------------------------------------

--
-- Table structure for table `bobot_gejala`
--

CREATE TABLE `bobot_gejala` (
  `id_bobot` int(11) NOT NULL,
  `nama_gejala` int(200) NOT NULL,
  `bobot` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `nama_gejala` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `nama_gejala`) VALUES
(1, 'rasa gatal'),
(5, 'bekas galian berbentuk luka'),
(7, 'muncul benjolan kemerahan'),
(9, 'galian timbul diarea lipatan'),
(11, 'keadaan kulit yang mengelupas'),
(13, 'kulit pecah-pecah'),
(15, 'tampak sekitar kulit terbakar'),
(17, 'sekitar kulit tampak berwarna kemerahan'),
(19, 'muncul gelembung berisi cairan'),
(21, 'kulit melepuh'),
(23, 'nyeri sekitar area gatal'),
(25, 'muncul ruam pada kulit'),
(27, 'demam'),
(29, 'kulit terasa kering'),
(31, 'kulit bernanah dan berair'),
(33, 'bengkak di area kulit'),
(35, 'sensasi kesemutan'),
(37, 'rasa gatal dimulut dan hidung'),
(39, 'koreng diarea luka');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit_gejala`
--

CREATE TABLE `penyakit_gejala` (
  `penyakit` varchar(100) NOT NULL,
  `gejala` varchar(500) NOT NULL,
  `nilai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `solusi`
--

CREATE TABLE `solusi` (
  `id_solusi` int(11) NOT NULL,
  `nama_penyakit` varchar(100) NOT NULL,
  `solusi` varchar(10000) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `solusi`
--

INSERT INTO `solusi` (`id_solusi`, `nama_penyakit`, `solusi`, `foto`) VALUES
(9, 'scabies', 'tes penyakit scabie', ' 64a74e3e699792.52403683.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_penyakit`
--

CREATE TABLE `tb_penyakit` (
  `id_penyakit` int(11) NOT NULL,
  `arr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_penyakit`
--

INSERT INTO `tb_penyakit` (`id_penyakit`, `arr`) VALUES
(1, '\"scabies\": {\n        \"rasa gatal\": 0.8,\n        \"bekas galian\": 0.6,\n        \"muncul benjolan\": 0.4,\n        \"galian timbul\": 0.2\n    },\n    \"tinea\": {\n        \"keadaan kulit mengelupas\": 0.7,\n        \"kulit pecah pecah\": 0.5,\n        \"rasa gatal\": 0.9,\n        \"tampak berwarna merah\": 0.3,\n        \"kulit bersisik\": 0.6\n    }');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `username`, `password`) VALUES
(1, 'administrator', 'admin', '123'),
(2, 'aa', 'aa', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bobot_gejala`
--
ALTER TABLE `bobot_gejala`
  ADD PRIMARY KEY (`id_bobot`),
  ADD UNIQUE KEY `nama_gejala` (`nama_gejala`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indexes for table `penyakit_gejala`
--
ALTER TABLE `penyakit_gejala`
  ADD PRIMARY KEY (`penyakit`);

--
-- Indexes for table `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`id_solusi`);

--
-- Indexes for table `tb_penyakit`
--
ALTER TABLE `tb_penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bobot_gejala`
--
ALTER TABLE `bobot_gejala`
  MODIFY `id_bobot` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id_gejala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `solusi`
--
ALTER TABLE `solusi`
  MODIFY `id_solusi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_penyakit`
--
ALTER TABLE `tb_penyakit`
  MODIFY `id_penyakit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bobot_gejala`
--
ALTER TABLE `bobot_gejala`
  ADD CONSTRAINT `bobot_gejala_ibfk_1` FOREIGN KEY (`nama_gejala`) REFERENCES `gejala` (`id_gejala`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
