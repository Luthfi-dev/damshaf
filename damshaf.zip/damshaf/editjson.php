<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Penyakit</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>
<body>
   <div class="container">
     <form method="POST">
  <textarea class="form-control" name="json_data" rows="10" cols="50">
    <?php 
    $data = file_get_contents("data.json");

    echo htmlspecialchars($data); ?>
</textarea>
<br><br>
  <button class="btn btn-danger" type="submit" name="save">Edit Data</button>
</form>
   </div>
</body>
</html>

<?php
if ($_POST) {
    // var_dump($_POST);
    file_put_contents("data.json",$_POST['json_data']);
}

