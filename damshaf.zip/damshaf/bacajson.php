<?php
// Membaca file teks
$fileContent = file_get_contents("data.txt");

// Mengembalikan string menjadi array asosiatif
$arrayData = json_decode($fileContent, true);

// Menampilkan array asosiatif yang dibaca
print_r($arrayData);