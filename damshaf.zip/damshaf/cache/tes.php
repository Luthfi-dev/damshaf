<!DOCTYPE html>
<html>
<head>
  <title>Prediksi Penyakit</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .fade-in {
      animation: fadeIn 1s forwards;
      opacity: 0;
    }
    
    .fade-out {
      animation: fadeOut 1s forwards;
      opacity: 1;
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
    
    @keyframes fadeOut {
      from {
        opacity: 1;
      }
      to {
        opacity: 0;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Prediksi Penyakit</h2>
    <form method="POST">
      <div id="gejalaForm">
        <div class="form-group">
          <label>Pilih Gejala:</label>
          <select class="form-control fade-in" name="gejala[]">
            <option value="rasa_gatal">Rasa Gatal</option>
            <option value="bekas_galian">Bekas Galian Berbentuk Luka</option>
            <option value="muncul_benjolan">Muncul Benjolan Kemerahan</option>
            <option value="galian_timbul">Galian Timbul di Area Lipatan</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="keadaan_kulit_mengelupas">Keadaan Kulit yang Mengelupas</option>
            <option value="kulit_pecah_pecah">Kulit Pecah-pecah</option>
            <option value="rasa_gatal_2">Rasa Gatal</option>
            <option value="tampak_berwarna_merah">Tampak Sekitar Kulit Terbakar</option>
            <option value="kulit_bersisik">Permukaan Kulit Bersisik</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="muncul_gelembung">Muncul Gelembung Berisi Cairan</option>
            <option value="kulit_bersisik_2">Permukaan Kulit Bersisik</option>
            <option value="tampak_berwarna_merah_2">Tampak Sekitar Kulit Terbakar</option>
            <option value="rasa_gatal_3">Rasa Gatal</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="rasa_gatal_4">Rasa Gatal</option>
            <option value="tampak_berwarna_merah_3">Tampak Sekitar Kulit Terbakar</option>
            <option value="muncul_gelembung_2">Muncul Gelembung Berisi Cairan</option>
            <option value="kulit_melepuh">Kulit Melepuh</option>
            <option value="nyeri_disekitar">Nyeri di Sekitar Area Gatal</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="rasa_gatal_5">Rasa Gatal</option>
            <option value="kulit_melepuh_2">Kulit Melepuh</option>
            <option value="muncul_gelembung_3">Muncul Gelembung Berisi Cairan</option>
            <option value="muncul_ruam">Muncul Ruam pada Kulit</option>
            <option value="tampak_berwarna_merah_4">Tampak Sekitar Kulit Terbakar</option>
            <option value="demam">Demam</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="keadaan_kulit_mengelupas_2">Keadaan Kulit yang Mengelupas</option>
            <option value="tampak_berwarna_merah_5">Tampak Sekitar Kulit Terbakar</option>
            <option value="kulit_bersisik_3">Permukaan Kulit Bersisik</option>
            <option value="kulit_terasa_kering">Kulit Terasa Kering</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="rasa_gatal_6">Rasa Gatal</option>
            <option value="tampak_berwarna_merah_6">Tampak Sekitar Kulit Terbakar</option>
            <option value="kulit_terasa_kering_2">Kulit Terasa Kering</option>
            <option value="muncul_benjolan_2">Muncul Benjolan Kemerahan</option>
            <option value="kulit_bersisik_4">Permukaan Kulit Bersisik</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="kulit_melepuh_3">Kulit Melepuh</option>
            <option value="tampak_berwarna_merah_7">Tampak Sekitar Kulit Terbakar</option>
            <option value="kulit_bernanah">Kulit Bernanah dan Berair</option>
            <option value="bengkak_diarea">Bengkak di Area Kulit</option>
            <option value="demam_2">Demam</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="rasa_gatal_7">Rasa Gatal</option>
            <option value="muncul_benjolan_3">Muncul Benjolan Kemerahan</option>
            <option value="sensasi_kesemutan">Sensasi Kesenangan</option>
            <option value="tampak_berwarna_merah_8">Tampak Sekitar Kulit Terbakar</option>
          </select>
        </div>
        <div class="form-group" style="display: none;">
          <label>Pilih Gejala:</label>
          <select class="form-control" name="gejala[]">
            <option value="tampak_berwarna_merah_9">Tampak Sekitar Kulit Terbakar</option>
            <option value="rasa_gatal_8">Rasa Gatal di Mulut dan Hidung</option>
            <option value="muncul_gelembung_4">Muncul Gelembung Berisi Cairan</option>
            <option value="koreng_diarea_luka">Koreng di Area Luka</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">Prediksi</button>
    </form>

    <?php
    // Dataset dengan bobot gejala dan penyakit
    $dataset = [
      'scabies' => [
        'rasa_gatal' => 0.8,
        'bekas_galian' => 0.6,
        'muncul_benjolan' => 0.4,
        'galian_timbul' => 0.2
      ],
      'tinea' => [
        'keadaan_kulit_mengelupas' => 0.7,
        'kulit_pecah_pecah' => 0.5,
        'rasa_gatal' => 0.9,
        'tampak_berwarna_merah' => 0.3,
        'kulit_bersisik' => 0.6
      ],
      'candidiasis' => [
        'muncul_gelembung' => 0.3,
        'kulit_bersisik' => 0.4,
        'tampak_berwarna_merah' => 0.5,
        'rasa_gatal' => 0.7
      ],
      'varicella' => [
        'rasa_gatal' => 0.9,
        'tampak_berwarna_merah' => 0.8,
        'muncul_gelembung' => 0.6,
        'kulit_melepuh' => 0.5,
        'nyeri_disekitar' => 0.2
      ],
      'herpes_zoster' => [
        'rasa_gatal' => 0.7,
        'kulit_melepuh' => 0.6,
        'muncul_gelembung' => 0.8,
        'muncul_ruam' => 0.4,
        'tampak_berwarna_merah' => 0.9,
        'demam' => 0.3
      ],
      'eczema' => [
        'keadaan_kulit_mengelupas' => 0.6,
        'tampak_berwarna_merah' => 0.8,
        'kulit_bersisik' => 0.5,
        'kulit_terasa_kering' => 0.7
      ],
      'dermatitis' => [
        'rasa_gatal' => 0.7,
        'tampak_berwarna_merah' => 0.9,
        'kulit_terasa_kering' => 0.8,
        'muncul_benjolan' => 0.4,
        'kulit_bersisik' => 0.3
      ],
      'impetigo' => [
        'kulit_melepuh' => 0.5,
        'tampak_berwarna_merah' => 0.7,
        'kulit_bernanah' => 0.6,
        'bengkak_diarea' => 0.4,
        'demam' => 0.2
      ],
      'insect_bite' => [
        'rasa_gatal' => 0.9,
        'muncul_benjolan' => 0.7,
        'sensasi_kesemutan' => 0.3,
        'tampak_berwarna_merah' => 0.5
      ],
      'herpes_simplex' => [
        'tampak_berwarna_merah' => 0.6,
        'rasa_gatal' => 0.8,
        'muncul_gelembung' => 0.7,
        'koreng_diarea_luka' => 0.4
      ]
    ];

    // if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //   $selectedGejala = $_POST['gejala'];
    error_reporting(0);
      $selectedGejala = [
        "rasa_gatal",'koreng_diarea_luka','muncul_benjolan','muncul_gelembung',
        "kulit_bernanah,tampak_berwarna_merah"
    ];
    //   var_dump($selectedGejala);
    //   echo"+++++++++++TOTAL BOBOT++++++++++++++";
      $totalBobot = [];

      foreach ($dataset as $penyakit => $gejalaBobot) {
        $penyakitBobot = 2;
echo "=======<br><br>GEJALA BOBOT========";
var_dump($gejalaBobot);
        foreach ($gejalaBobot as $gejala => $bobot) {
echo "=======<br><br>BOBOT========";
print_r($bobot);
          if (in_array($gejala, $selectedGejala)) {
            $penyakitBobot *= $bobot;
          } else {
            $penyakitBobot *= (1 - $bobot);
          }
          echo "----<br><br>BOBOT PENYAKIT----";
          print_r($penyakitBobot);
        }

        $totalBobot[$penyakit] = $penyakitBobot;
      }

      // Menghitung nilai keyakinan
      $totalBobotSum = array_sum($totalBobot);
      $keyakinan = [];

        echo "=======<br><br>TOTAL BOBOT SUM========";
        print_r($totalBobotSum);

      foreach ($totalBobot as $penyakit => $bobot) {
        $keyakinan[$penyakit] = $bobot / $totalBobotSum;
      }

      // Menampilkan hasil prediksi
      arsort($keyakinan);
      $penyakitTerprediksi = key($keyakinan);
      $nilaiKeyakinan = current($keyakinan);
        echo "=======<br><br>TOTAL BOBOT KEYAKINAN========";
        print_r($keyakinan);
        // foreach ($nilaiKeyakinan as $k) {
        //   echo $k;
        // }

      echo '<h4>Hasil Prediksi:</h4>';
      echo '<p>Pasien kemungkinan mengalami penyakit <strong>' . $penyakitTerprediksi . '</strong> dengan tingkat keyakinan ' . $nilaiKeyakinan . '</p>';
    // }
    ?>
  </div>
</body>
</html>
