<?php 
	$url = file_get_contents('https://api.kawalcorona.com/indonesia/');
	$url1 = file_get_contents('https://api.kawalcorona.com');

	$data = json_decode($url,true);
	$data1 = json_decode($url1,true);


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" />
<title>Data Covid-19</title>
<meta name="rating" content="general" />
<meta name="distribution" content="global" />
<meta name="copyright" content="GreenSSH" />
<meta name="description" content="deskripsi">
<meta name="keywords" content="kata kunci">
<meta property="og:url" content="http://coda.luth.ga/" />
<meta property="og:type" content="website" />
<meta property="og:title" content="titel" />
<meta property="og:image" content="http://coda.luth.ga/assets/images/preview.jpg" />
<meta name="theme-color" content="#0E2546">
<meta name="google-site-verification" content="gcYFMYOQ9HQtecaQtXu6CEBZo2Gq00_OTmymvyAq6zU" />
<meta name="msvalidate.01" content="D9698C9116E7B0231DECE294D79BCB6C" />
<link rel="shortcut icon" href="assets/images/favicon.svg">
<link rel="stylesheet" href="assets/sbadmin/styles.css?v=0.1">
<link rel="dns-prefetch" href="https://greenssh.com">
<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.24.1/feather.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-108810705-1" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script type="0d8ecd71836342666086aa7a-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-108810705-1');
</script>

<script type="0d8ecd71836342666086aa7a-text/javascript">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KN126F85VK');
</script>

<style type="text/css">
  .img-cover {
    background: url('assets/images/virus.jpeg'); 
    background-repeat: no-repeat;
    background-size: cover;
  }
  .kotak {
    width: 100px;
    height: 100px;
    background-color: white;
    border-radius: 20px;
    color: black;
    padding: 5px;
    margin: 4px;
    text-align: center;
    border: 2px solid silver;
    box-shadow: 0 0 3px 2px lightblue;
  }
  .alig {
    line-height: 60px;
  }
</style>

</head>
<body>
<div id="layoutDefault">
<div id="layoutDefault_content">
<main><nav class="navbar navbar-marketing navbar-expand-lg bg-white navbar-light fixed-top">
<div class="container-fluid">
<a class="navbar-brand" href="#">
  <span><img style="margin-top: -10px" src="assets/images/icon_virus.png"></span>
  <span style="width: 167px; height: 32px; font-size: 1.5em;color: blue">Covid.info</span>
</a><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i data-feather="menu"></i></button>
<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">


<!-- MENU -->
<ul class="navbar-nav ml-lg-5 ml-auto mr-lg-5">
<li class="nav-item"><a class="nav-link" href="/">Home </a></li>
<li class="nav-item"><a class="nav-link" href="data.php">Data covid</a></li>
<li class="nav-item"><a class="nav-link" href="#">Login</a></li>
<li class="nav-item"><a class="nav-link" href="#">Register</a></li>
<li class="nav-item"><a class="nav-link" href="#">Logout</a></li>
</ul>

</div>
</div>
</nav>

<!-- content -->
<div class="mt-10">
	<div class="container">

		<div class="col-lg-6 mb-5" style="padding: 0;">
			<h3 style="color: lightblue">Data Covid-19 Indonesia</h3>
			<div class="row">
				<div class="col kotak">
					<h5 class="bg-light">Positif</h5>
					<p style="margin-top:15px"><b><?php echo $data[0]['positif']; ?></b></p>
				</div>

				<div class="col kotak">
					<h5 class="bg-light">Sembuh</h5>
					<p style="margin-top:15px"><b><?php echo $data[0]['sembuh'] ?></b></p>
				</div>

				<div class="col kotak">
					<h5 class="bg-light">Meninggal</h5>
					<p style="margin-top:15px"><b><?php echo $data[0]['meninggal'] ?></b></p>
				</div>

				<div class="col kotak">
					<h5 class="bg-light">Dirawat</h5>
					<p style="margin-top:15px"><b><?php echo $data[0]['dirawat'] ?>
				</b></p>
			</div>
		</div>
	</div>

<h3>Data Covid Negara Lain</h3>
<h6>(Sumber dari : kawalcorona)</h6>

<table class="table table-striped">
                  <thead>
                    <tr>
                      <th scope="col">No.</th>
                      <th scope="col">Negara</th>
                      <th scope="col">Dikomfirmasi</th>
                      <th scope="col">Meninggal</th>
                    </tr>
                  </thead>
                  <tbody>
<?php for ($i=0; $i < count($data1); $i++) { ?>
<tr>
	<td><?= $i+1; ?>.</td>
	<td>
		<?php echo $data1[$i]['attributes']['Country_Region'];
		echo "<br><br>"; ?>
	</td>

	<td>
		<?php echo $data1[$i]['attributes']['Confirmed'];
		echo "<br><br>"; ?>
	</td>

	<td>
		<?php echo $data1[$i]['attributes']['Deaths'];
		echo "<br><br>"; ?>
	</td>
</tr>         	
<?php } ?>
	
                  </tbody>
                </table>

</div>
</div>

<!-- end content -->

<script src="assets/js/jquery.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/js/script.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/sbadmin/scripts.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/js/jquery.countdown.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>

<script src="https://unpkg.com/aos@next/dist/aos.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script type="0d8ecd71836342666086aa7a-text/javascript">
            AOS.init({
                disable: 'mobile',
                duration: 600,
                once: true
            });
        </script>
<script src="assets/rocket-loader.min.js" data-cf-settings="0d8ecd71836342666086aa7a-|49" defer=""></script></body>
</html>

