<!-- Contoh inputan radio -->
<label>
  <input type="radio" name="option" value="option1">
  Pilihan 1
</label>

<label>
  <input type="radio" name="option" value="option2">
  Pilihan 2
</label>

<label>
  <input type="radio" name="option" value="option3">
  Pilihan 3
</label>

<label>
  <input type="radio" name="option" value="option4">
  Pilihan 4
</label>

<label>
  <input type="radio" name="option" value="option5">
  Pilihan 5
</label>

<button id="submitBtn">Submit</button>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    $("#submitBtn").click(function() {
      var selectedOptions = []; // Array untuk menyimpan pilihan yang dipilih

      // Perulangan untuk setiap inputan radio
      $('input[type="radio"]:checked').each(function() {
        var value = $(this).val(); // Mengambil nilai dari inputan radio yang dipilih
        selectedOptions.push(value); // Menyimpan nilai dalam array
      });

      console.log(selectedOptions); // Menampilkan array pilihan yang dipilih
    });
  });
</script>
