<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Display Questions</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <style>
    .question-container {
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
      text-align: center;
      opacity: 1;
      transition: opacity 0.5s ease-in-out;
    }
    .fade-out {
      opacity: 0;
    }
    .p-0 {padding:0}
  </style>
</head>
<body>
  <div class="container">
    <h6>Apakah terdapat gejala berikut, pilih sesuai gejala yang dialami</h6>
    <!-- <form id="myForm" action="d.php" method="GET"> -->
        <div id="questions-container">
        </div>
        <!-- <button>submit</button> -->
    <!-- </form> -->
    <!-- <button id="next-btn" class="btn btn-primary">Next</button> -->
    <span id="next-btn" onclick="submitGejala()" class='btn btn-light mb-2 mr-2 w-100 shadow'>Tidak ada pilihan di atas</span>
    <button id="next-btn" class="btn btn-primary" onclick="submitGejala()">Lanjut</button>
</div>

  <script>

    // Daftar pertanyaan
    var questions = [
      "Question 1",
      "Question 2",
      "Question 3",
      "Question 4",
      "Question 5",
      "Question 6",
      "Question 7",
      "Question 8",
      "Question 9",
      "Question 10",
      "Question 11",
      "Question 12",
      "Question 13",
      "Question 14",
      "Question 15",
      "Question 16",
      "Question 17",
      "Question 18",
      "Question 19",
      "Question 20"
    ];

    // mengambil value dari pilhan
            var selectedGejala = [];
    function submitGejala() {
            $("input[name='gejala[]']:checked").each(function() {
                selectedGejala.push($(this).val());
            });
            console.log(selectedGejala);
            if (selectedGejala.length > 0) {
                // $.ajax({
                //     type: "POST",
                //     url: "backend.php",
                //     data: { selectedGejala: selectedGejala },
                //     dataType: "json",
                //     success: function(data) {
                //         showResult(data);
                //     }
                // });
                console.log("oke");
            }
        }
    console.log(selectedGejala);
    var currentIndex = 0;
    var questionsPerPage = 5;

    // Menampilkan pertanyaan
    function displayQuestions() {
      var questionsContainer = $("#questions-container");
      questionsContainer.empty();

      for (var i = currentIndex; i < currentIndex + questionsPerPage; i++) {
        if (i >= questions.length) {
          break;
        }

            var question = questions[i];
            var questionElement = $("<div>").text(question);
            console.log(questionElement);
            console.log(question);
            questionsContainer.append("<button class='btn btn-light mb-2 mr-2 w-100 shadow tanya'><input class='mr-3' type='checkbox' name='gejala[]' value='"+question+"'/>"+question+"</button><br>");

      }
    }

    // Menampilkan pertanyaan selanjutnya
    function showNextQuestions() {
      currentIndex += questionsPerPage; 
        displayQuestions();
            
    console.log(currentIndex,questionsPerPage)
        if (currentIndex >= 20) {
            window.location.href="diagnosa.php?plh="+selectedGejala;
        }
    }


    // Memuat pertanyaan pertama kali
    displayQuestions();

    // Mengikat event click pada tombol Next
    $("#next-btn").click(function() {
        // setTimeout(function() {
        // $('.questions-container').removeClass('fade-out').addClass('d-none');

        // }, 500);
            showNextQuestions();


    });
  </script>
</body>
</html>
