<?php
// Fungsi untuk menggabungkan massa bukti menggunakan aturan Dempster
function gabungMassa($massa1, $massa2)
{
    $massaGabung = ($massa1 + $massa2) / (1 - ($massa1 * $massa2));
    return $massaGabung;
}

// Daftar gejala
$gejala = [
    'gejala1' => 'kepala sakit',
    'gejala2' => 'gusi berdarah',
    'gejala3' => 'pusing',
    'gejala4' => 'batuk',
    'gejala5' => 'sakit perut'
];

// Daftar penyakit dan massa bukti untuk setiap gejala
$penyakit = [
    'penyakit1' => [
        'gejala1' => 0.4,
        'gejala2' => 0.6,
        'gejala3' => 0.8,
        'gejala4' => 0.3,
        'gejala5' => 0.2
    ],
    'penyakit2' => [
        'gejala1' => 0.7,
        'gejala2' => 0.2,
        'gejala3' => 0.5,
        'gejala4' => 0.6,
        'gejala5' => 0.4
    ],
    'penyakit3' => [
        'gejala1' => 0.3,
        'gejala2' => 0.4,
        'gejala3' => 0.6,
        'gejala4' => 0.7,
        'gejala5' => 0.5
    ]
];

// Ambil gejala yang dipilih dari frontend
$selectedGejala = $_POST['selectedGejala'];

// Hitung massa gabungan untuk setiap penyakit berdasarkan gejala yang dipilih
$massaGabung = [];
foreach ($penyakit as $namaPenyakit => $gejalaPenyakit) {
    $massaGabungPenyakit = 1; // Massa awal setiap penyakit adalah 1 (pasti)
    foreach ($selectedGejala as $gejala) {
        if (isset($gejalaPenyakit[$gejala])) {
            $massaGabungPenyakit = gabungMassa($massaGabungPenyakit, $gejalaPenyakit[$gejala]);
        }
    }
    $massaGabung[$namaPenyakit] = $massaGabungPenyakit;
}

// Normalisasi massa gabungan
$totalMassaGabung = array_sum($massaGabung);
$massaNormalisasi = [];
foreach ($massaGabung as $namaPenyakit => $massaGabungPenyakit) {
    $massaNormalisasiPenyakit = $massaGabungPenyakit / $totalMassaGabung;
    $massaNormalisasi[$namaPenyakit] = $massaNormalisasiPenyakit;
}

// Urutkan daftar penyakit berdasarkan tingkat keyakinan tertinggi
arsort($massaNormalisasi);

// Mengembalikan hasil ke frontend
echo json_encode($massaNormalisasi);
?>
