<!DOCTYPE html>
<html>
<head>
  <title>Loading Animation</title>
  <style>
    .loading-container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .loading-circle {
      width: 100px;
      height: 100px;
      border: 10px solid #f3f3f3;
      border-top: 10px solid #3498db;
      border-radius: 50%;
      animation: spin 5s linear infinite;
    }

    .loading-text {
      margin-top: 10px;
      text-align: center;
      font-weight: bold;
      font-size: 24px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  <div class="loading-container">
    <div class="loading-circle"></div>
    <div class="loading-text" id="countdown" style="margin-left:-80px">0</div>%
    <div style="margin-left:-80px;margin-bottom:-150px">Tingkat keyakinan...</div>
  </div>

  <script>
    // Menghitung angka dari 0 hingga 50 dalam 5 detik
    let counter = 0;
    const target = 50;
    const duration = 5;
    const step = target / (duration * 1000 / 10);

    const countdown = document.getElementById("countdown");

    const interval = setInterval(() => {
      counter += step;
      countdown.textContent = Math.round(counter);

      if (counter >= target) {
        clearInterval(interval);
        countdown.textContent = target;
      }
    }, 10);
  </script>
</body>
</html>
