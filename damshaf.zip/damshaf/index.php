
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" />
<title>Gejala Penyakit</title>
<meta name="rating" content="general" />
<meta name="distribution" content="global" />
<meta name="copyright" content="GreenSSH" />
<meta name="description" content="deskripsi">
<meta name="keywords" content="kata kunci">
<meta property="og:url" content="http:/firza.online/" />
<meta property="og:type" content="website" />
<meta property="og:title" content="titel" />
<meta property="og:image" content="http://firza.online/assets/images/icon_virus.png" />
<meta name="theme-color" content="#0E2748">
<meta name="google-site-verification" content="gcYFMYOQ9HQtecaQtXu6CEBZo2Gq00_OTmymvyAq6zU" />
<meta name="msvalidate.01" content="D9698C9116E7B0231DECE294D79BCB6C" />
<link rel="shortcut icon" href="assets/images/icon_virus.png">
<link rel="stylesheet" href="assets/sbadmin/styles.css?v=0.1">
<link rel="dns-prefetch" href="https://greenssh.com">
<script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.24.1/feather.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>

<style type="text/css">
  .img-cover {
    background: url('assets/images/virus.jpeg'); 
    background-repeat: no-repeat;
    background-size: cover;
  }
  .kotak {
    width: 100px;
    height: 100px;
    background-color: white;
    border-radius: 20px;
    color: black;
    padding: 5px;
    margin: 4px;
    text-align: center;
    border: 2px solid silver;
    box-shadow: 0 0 3px 2px lightblue;
  }
  .alig {
    line-height: 60px;
  }
</style>

</head>
<body>
<div class="container p-0" style="margin:0 center;max-width:567px;">
<div id="layoutDefault">
<div id="layoutDefault_content">
<main><nav class="navbar navbar-marketing navbar-expand-lg bg-white navbar-light fixed-top">
<div class="container-fluid">
<a class="navbar-brand" href="#">
  <span><img style="margin-top: -10px" src="assets/images/icon_virus.png"></span>
  <span style="width: 167px; height: 32px; font-size: 1.5em;color: #11223E">Klik Gejala</span>
</a><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i data-feather="menu"></i></button>
<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">

<!-- MENU -->
<ul class="navbar-nav ml-lg-5 ml-auto mr-lg-5">
<li class="nav-item"><a class="nav-link" href="#">Home </a></li>
<li class="nav-item"><a class="nav-link" href="gejala.php">Cek Gejala</a></li>
<li class="nav-item"><a class="nav-link" href="#keunggulan">Keunggulan</a></li>
<li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
</ul>

</div>
</div>
</nav> 
<header class="page-header page-header-dark img-cover">
<div class="page-header-content pt-10">
<div class="container">
 <div class="row align-items-center">
<div class="col-lg-12 mb-5" data-aos="fade-up">
<h1 class="page-header-title">Mengalami gejala sakit tapih bingung itu gejala penyakit apa??</h1>
<p class="page-header-text mb-3">
  Tenang! tidak perlu khawatir untuk buru-bur langsung ngecek ke dokter, kamu bisa terlebih dahulu mengecek lewat aplikasi klik gejala, 
  aplikasi ini bisa memprediksi penyakit sesuai gejala yang di alami dengan menggunakan metode Dempster shafer,
  untuk memulai cek gejela klik tombol dibawah!
</p>
<a class="btn btn-light btn-marketing rounded-pill" href="gejala.php">Cek Gejala Sekarang<i class="fas fa-arrow-right ml-1"></i></a>
</div>
  </div>
</div>





<!-- <div class="col-lg-6 d-block d-lg-block" data-aos="fade-up" data-aos-delay="50"><img class="img-fluid" src="assets/images/medis.svg" width="450" height="450" alt="sshocean" /></div>
</div> -->
</div>
</div>

<!-- <div class="svg-border-waves text-light" style="max-width:567px;">
<svg class="wave" style="pointer-events: none" fill="currentColor" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 75">
<defs>
  <style>
    .a {
      fill: none;
    }
    .b {
      clip-path: url(#a);
    }
    .d {
      opacity: 0.5;
      isolation: isolate;
    }
  </style>
<clippath id="a"><rect class="a" width="567" height="75" style="margin-left:-300px"></rect></clippath>
</defs>
<title>wave</title>
<g class="b"><path class="c" d="M1963,327H-105V65A2647.49,2647.49,0,0,1,431,19c217.7,3.5,239.6,30.8,470,36,297.3,6.7,367.5-36.2,642-28a2511.41,2511.41,0,0,1,420,48"></path></g>
<g class="b"><path class="d" d="M-127,404H1963V44c-140.1-28-343.3-46.7-566,22-75.5,23.3-118.5,45.9-162,64-48.6,20.2-404.7,128-784,0C355.2,97.7,341.6,78.3,235,50,86.6,10.6-41.8,6.9-127,10"></path></g>
<g class="b"><path class="d" d="M1979,462-155,446V106C251.8,20.2,576.6,15.9,805,30c167.4,10.3,322.3,32.9,680,56,207,13.4,378,20.3,494,24"></path></g>
<g class="b"><path class="d" d="M1998,484H-243V100c445.8,26.8,794.2-4.1,1035-39,141-20.4,231.1-40.1,378-45,349.6-11.6,636.7,73.8,828,150"></path></g>
</svg> -->

</div>
</header>
<section class="bg-light py-5 mt-3">
<div class="container" id="keunggulan">
<div class="row justify-content-center">
<div class="col-lg-10">
<div class="mb-5 text-center">
<div class="text-xs text-uppercase-expanded text-primary mb-2">Kenapa Aplikasi ini dibuat?</div>
<p class="lead mb-0">Aplikasi ini dibuat terutama untuk tugas akhir dan untuk membantu orang-orang dalam mengetahui penyakit yang di alami hanya dengan menggunakan gejala yang di rasakan</p>
</div>
</div>
</div>

</div>
</section>

<section class="bg-white py-5">
<div class="container">
<div class="row text-center">
<div class="col-12 mb-2">
<!-- <div class="badge badge-success-soft text-success badge-marketing badge-pill mb-2">
<div id="clockwelcome"></div>
</div> -->
</div>
<div class="col-lg-12 mb-5 mb-lg-0">
<div class="icon-stack icon-stack-xl bg-gradient-primary-to-secondary text-white mb-4 img-cover"><i data-feather="user"></i></div>
<h3>Membantu Pengguna</h3>
<p class="mb-0">Dengan Menggunakan Aplikasi ini kami harapkan dapat memudahkan pengguna dalam Diagnosa penyakit tahap awal</p>
</div>
<div class="col-lg-12 mb-5 mb-lg-0">
<div class="icon-stack icon-stack-xl bg-gradient-primary-to-secondary text-white mb-4 img-cover"><i data-feather="dollar-sign"></i></div>
<h3>Gratis Biaya</h3>
<p class="mb-0">Kami tidak memungut biaya sama sekali saat anda menggunakan aplikasi kami</p>
</div>
<div class="col-lg-12">
<div class="icon-stack icon-stack-xl bg-gradient-primary-to-secondary text-white mb-4 img-cover"><i data-feather="zap"></i></div>
<h3>Koneksi Cepat</h3>
<p class="mb-0">Aplikasi yang kami buat sudah kami usahakan secepat mungkin dalam proses Diagnosa penyakit </p>
</div>
</div>
</div>
</section>

<section class="bg-dark py-10">
<div class="container">
<div class="row my-10">
<div class="col-lg-6" data-aos="fade-right" data-aos-delay="0">
<div class="d-flex h-100">
<div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-hdd"></i></div>
<div class="ml-4">
<h5 class="text-white">Server Gratis</h5>
<p class="text-white-50">Server yang kami sediakan untuk saat ini kami biayai sendiri tanpa ada sokongan sedikitpun</p>
</div>
</div>
</div>
<div class="col-lg-6" data-aos="fade-left" data-aos-delay="0">
<div class="d-flex h-100">
<div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-check-circle"></i></div>
<div class="ml-4">
<h5 class="text-white">Akses tanpa Batas</h5>
<p class="text-white-50">Anda bebas mengakses aplikasi ini kapanpu dan dimanapun tanpa di batasi limit akses sama sekali</p>
</div>
</div>
</div>
<div class="col-lg-6" data-aos="fade-right" data-aos-delay="50">
<div class="d-flex h-100">
<div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-lock"></i></div>
<div class="ml-4">
<h5 class="text-white">encryption</h5>
<p class="text-white-50">aplikasi kami telah terenskripsi, jadi anda tidak perlu khawatir untuk keamanan data yang di input di dalam aplikasi</p>
</div>
</div>
</div>
<div class="col-lg-6" data-aos="fade-left" data-aos-delay="50">
<div class="d-flex h-100">
<div class="icon-stack flex-shrink-0 bg-teal text-white"><i class="fas fa-chart-line"></i></div>
<div class="ml-4">
<h5 class="text-white">Unlimited Data Transfer</h5>
<p class="text-white-50">Data di transfer setiap waktu kapanpun yang anda perlukan</p>
</div>
</div>
</div>

</div>
</div>
<center>Copyright 2023 | Firza Fitria</center>
</section> 
</div>
</div>
<script src="assets/js/jquery.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/js/script.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/sbadmin/scripts.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>
<script src="assets/js/jquery.countdown.min.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>

<script src="https://unpkg.com/aos@next/dist/aos.js" type="0d8ecd71836342666086aa7a-text/javascript"></script>

<script src="assets/rocket-loader.min.js" data-cf-settings="0d8ecd71836342666086aa7a-|49" defer=""></script>
</div>
</body>
</html>
