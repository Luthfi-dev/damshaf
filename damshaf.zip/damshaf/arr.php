<?php
$data = [
    'scabies' => [
        'rasa gatal' => 0.8,
        'bekas galian' => 0.6,
        'muncul benjolan' => 0.4,
        'galian timbul' => 0.2
    ],
    'tinea' => [
        'keadaan kulit mengelupas' => 0.7,
        'kulit pecah pecah' => 0.5,
        'rasa gatal' => 0.9,
        'tampak berwarna merah' => 0.3,
        'kulit bersisik' => 0.6
      ],
      'candidiasis' => [
        'muncul gelembung' => 0.3,
        'kulit bersisik' => 0.4,
        'tampak berwarna merah' => 0.5,
        'rasa gatal' => 0.7
      ],
      'varicella' => [
        'rasa gatal' => 0.9,
        'tampak berwarna merah' => 0.8,
        'muncul gelembung' => 0.6,
        'kulit melepuh' => 0.5,
        'nyeri disekitar' => 0.2
      ],
      'herpes zoster' => [
        'rasa gatal' => 0.7,
        'kulit melepuh' => 0.6,
        'muncul gelembung' => 0.8,
        'muncul ruam' => 0.4,
        'tampak berwarna merah' => 0.9,
        'demam' => 0.3
      ],
      'eczema' => [
        'keadaan kulit mengelupas' => 0.6,
        'tampak berwarna merah' => 0.8,
        'kulit bersisik' => 0.5,
        'kulit terasa kering' => 0.7
      ],
      'dermatitis' => [
        'rasa gatal' => 0.7,
        'tampak berwarna merah' => 0.9,
        'kulit terasa kering' => 0.8,
        'muncul benjolan' => 0.4,
        'kulit bersisik' => 0.3
      ],
      'impetigo' => [
        'kulit melepuh' => 0.5,
        'tampak berwarna merah' => 0.7,
        'kulit bernanah' => 0.6,
        'bengkak diarea' => 0.4,
        'demam' => 0.2
      ],
      'insect bite' => [
        'rasa gatal' => 0.9,
        'muncul benjolan' => 0.7,
        'sensasi kesemutan' => 0.3,
        'tampak berwarna merah' => 0.5
      ],
      'herpes simplex' => [
        'tampak berwarna merah' => 0.6,
        'rasa gatal' => 0.8,
        'muncul gelembung' => 0.7,
        'koreng diarea luka' => 0.4
      ]
    ];

$en = json_encode($data);
$de = json_decode($en);

var_dump($en);
echo "<br><br>";
print_r($de);

