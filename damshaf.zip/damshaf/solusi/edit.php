<!DOCTYPE html>
<html>
<head>
     <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data solusi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
</head>
<body>
    <div class="container" style="margin:0 center;max-width:567px;">
        <h2>Edit Data Solusi</h2>

        <?php
        // Koneksi ke database
        include("../koneksi.php");

        // Periksa apakah form telah disubmit
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            var_dump($_POST);
            // Mendapatkan data dari form
            $id = $_POST["id"];
            $namaPenyakit = $_POST["nama_penyakit"];
            $solusi = $_POST["solusi"];

            // Update data gejala ke database
            $query = "UPDATE solusi SET nama_penyakit='$namaPenyakit',solusi='$solusi' WHERE id_solusi='$id_solusi'";
            $result = mysqli_query($koneksi, $query);

            // Cek apakah update berhasil
            if ($result) {
                echo "<div class='alert alert-success'>Data gejala berhasil diupdate.</div>";
                header("Location: ../solusi");

            } else {
                echo "<div class='alert alert-danger'>Terjadi kesalahan saat mengupdate data gejala.</div>";
            }
        }

        // Mendapatkan ID gejala dari parameter URL
        $id = $_GET["id"];

        // Query untuk mendapatkan data gejala berdasarkan ID
        $query = "SELECT * FROM solusi WHERE id_solusi=$id";
        $result = mysqli_query($koneksi, $query);
        $row = mysqli_fetch_assoc($result);
        // var_dump($row);
        ?>

        

        <form id="myForm" method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <div class="form-group">
                <label for="nama_penyakit">Nama Penyakit:</label>
                <input type="text" class="form-control" id="nama_penyakit" name="nama_penyakit" value="<?php echo $row['nama_penyakit']; ?>" required>
            </div>

            <div class="form-group">
                <label for="nama_penyakit">Foto Penyakit:</label>
                <?php echo $row['foto']; ?>
                <center>
                    <img src="<?php echo "../gambar/" . trim($row['foto']," "); ?>" width=200  alt="">
                </center>
            </div>

            <div class="form-group">
                <label for="solusi">Solusi:</label>
                <textarea class="form-control" id="solusi" name="solusi" rows="4" required><?php echo $row['solusi']; ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        CKEDITOR.replace('solusi');

        // $(document).ready(function() {
        //     // Ambil referensi form
        //     var form = $('#myForm');

        //     // Tambahkan event listener untuk event submit
        //     form.on('submit', function(event) {
        //         // Mencegah refresh halaman
        //         event.preventDefault();
        //     });
        //     });


    </script>
</body>
</html>
