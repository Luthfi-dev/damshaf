<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Solusi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container" style="margin:0 center;max-width:567px;">
        <h2>Data Solusi</h2>
        <a href="tambah.php" class="btn btn-primary">Tambah Data</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Nama Penyakit</th>
                    <th>Solusi</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Koneksi ke database
                $koneksi = mysqli_connect("localhost", "root", "", "d_virza");

                // Query untuk mendapatkan data gejala
                $query = "SELECT * FROM solusi";
                $result = mysqli_query($koneksi, $query);

                // Loop melalui setiap baris data
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td class='text-primary'>" . $row['nama_penyakit'] . "</td>";
                    echo "<td class='text-success'><h5>" . $potong = substr($row['solusi'],0,80) ."</h5><b> ....Selengkapnya klik edit -></b></td>";
                    echo "<td>
                            <div class='dropdown'>
                                <button class='btn btn-secondary dropdown-toggle' type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                    <i class='fas fa-ellipsis-v'></i>
                                </button>
                                <div class='dropdown-menu' aria-labelledby='dropdownMenuButton'>
                                    <a class='dropdown-item' href='edit.php?id=".$row['id_solusi']. "'>Edit</a>
                                    <a class='dropdown-item' href='#'>Hapus</a>
                                </div>
                            </div>
                        </td>";
                    echo "</tr>";
                }

                // 

                // Menutup koneksi database
                mysqli_close($koneksi);
                ?>
            </tbody>
        </table>
    </div>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
