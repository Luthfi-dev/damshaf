<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data solusi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
</head>
<body>
    <div class="container" style="margin:0 center;max-width:567px;">
        <h2>Tambah Data Solusi</h2>

        <?php
        // Koneksi ke database
        include("../koneksi.php");
?>

<?php
        if (isset($_POST['nama_penyakit'])) {
            // echo "<script>alert('Daat')</script>";
            // Mengambil informasi file gambar
            $file = $_FILES['dok'];
            $fileName = $file['name'];
            $fileTmpName = $file['tmp_name'];
            $fileSize = $file['size'];
            $fileError = $file['error'];

            // Mengambil ekstensi file
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            // Menentukan ekstensi file yang diizinkan
            $allowedExtensions = array('jpg', 'jpeg', 'png');

            if (in_array($fileExt, $allowedExtensions)) {
                if ($fileError === 0) {
                    if ($fileSize < 5000000) { // Batasan ukuran file (dalam byte)
                        $newFileName = uniqid('',true) . '.' . $fileExt;
                        $fileDestination = '../gambar/' . $newFileName;

                        // Memindahkan file gambar ke folder aplikasi
                        move_uploaded_file($fileTmpName, $fileDestination);

                        if ($koneksi->connect_error) {
                            die("Koneksi database gagal: " . $koneksi->connect_error);
                        }
                        
                         // Mendapatkan data dari form
                            $id = $_POST["id"];
                            $namaPenyakit = $_POST["nama_penyakit"];
                            $solusi = $_POST["solusi"];

                            // Update data gejala ke database
                            $query = "INSERT INTO solusi VALUES('','$namaPenyakit','$solusi',' $newFileName')";
                            $result = mysqli_query($koneksi, $query);

                            // Cek apakah update berhasil
                            if ($result) {
                                
                                echo "<div class='alert alert-success'>Data gejala berhasil Disimpan.</div>";
                                header("Location: ../solusi");

                            } else {
                                echo "<div class='alert alert-danger'>Terjadi kesalahan saat mengimput data gejala.</div>";
                            }

                        $koneksi->close();
                    } else {
                        echo '<script>alert("Ukuran file terlalu besar. Maksimum 5MB.")</script>';
                    }
                } else {
                    echo '<script>alert("Terjadi kesalahan saat mengunggah file.")</script>';
                }
            } else {
                echo '<script>alert("Ekstensi file tidak diizinkan. Hanya file JPG, JPEG, dan PNG yang diizinkan.")</script>';
            }
        }
        ?>

        <form id="myForm" method="POST" action="" enctype="multipart/form-data">

            <div class="form-group">
                <label for="nama_penyakit">Nama Penyakit:</label>
                <input type="text" class="form-control" name="nama_penyakit" required accept="image/*" onchange="previewImage(event)">
            </div>

            <div class="form-group">
                <label for="nama_penyakit">Foto Penyakit:</label>
                <input type="file" class="form-control" id="dok" name="dok" required onchange="previewImage(event)">
            </div>
            <center>
                <img id="preview" src="#" alt="Pratinjau Gambar" style="max-width: 200px; max-height: 200px;">
            </center>

            <div class="form-group">
                <label for="solusi">Solusi:</label>
                <textarea class="form-control" id="solusi" name="solusi" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Tambah</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        CKEDITOR.replace('solusi');

        // $(document).ready(function() {
        //     // Ambil referensi form
        //     var form = $('#myForm');

        //     // Tambahkan event listener untuk event submit
        //     form.on('submit', function(event) {
        //         // Mencegah refresh halaman
        //         event.preventDefault();
        //     });
        //     });
        </script>
<script>
    function previewImage(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('preview');
        output.src = reader.result;
        $("#preview").show(); // Menampilkan pratinjau gambar
    }
    reader.readAsDataURL(event.target.files[0]);
}


$("#preview").hide(); // Menyembunyikan pratinjau gambar

    </script>
</body>
</html>
