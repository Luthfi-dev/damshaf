<form action="" method="POST">
  <label >Berapa jumlah penyakit</label><br>
  <input type="number" name="jml">
  <button type="submit">buat</button>
</form>

<form method="POST" action="">
  <?php
  var_dump($_POST);
   if ($_POST['jml']) {
     for ($i=0; $i < 5; $i++) { ?>
     <br><br><br>
      <label for="penyakit">Penyakit:</label>
      <input type="text" name="penyakit" id="penyakit" required>
      <br><br>

      <label for="gejala">Gejala:</label><br>
      <input type="text" name="gejala[]" required>
      <input type="number" name="nilai[]" step="0.1" min="0" max="1" required>
      <br><br>

      <button type="button" id="addGejala">Tambah Gejala</button>
      <br><br><br>
  <?php
    }
   }
  ?>

  <input type="submit" value="Submit">
</form>

<script>
  document.getElementById('addGejala').addEventListener('click', function() {
    var gejalaContainer = document.createElement('div');
    gejalaContainer.innerHTML = `
      <input type="text" name="gejala[]" required>
      <input type="number" name="nilai[]" step="0.1" min="0" max="1" required>
      <br><br>
    `;
    document.querySelector('form').insertBefore(gejalaContainer, this);
  });
</script>


<?php

// var_dump($_POST['gejala']);
// var_dump($_POST['nilai']);

if ($_POST['gejala']) {
    $data = [];

    // Mendapatkan nilai penyakit
    $penyakit = $_POST['penyakit'];

    // Mendapatkan nilai gejala dan nilai
    $gejala = $_POST['gejala'];
    $nilai = $_POST['nilai'];

    // Membentuk array data
    $data[$penyakit] = array_combine($gejala, $nilai);

    // Menampilkan hasil array data
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}


?>