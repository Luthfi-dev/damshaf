<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gejala Penyakit</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>
<body>

<form id="formDataset" method="POST" action="">
  <div id="datasetContainer"></div>
<br><br>
  <button class="btn btn-primary" type="button" id="addPenyakit">++ Tambah Penyakit</button>
  <br><br>

  <input class="btn btn-success" type="submit" value="Submit">
</form>
<br><br><br>
<form id="simpan" style="display:none" action="simpan_arr.php" method="POST">
    <input id="outputContainer" name="hasil"/>
    <br><br>
    <button class="btn btn-danger">Simpan Ke Database</button>
</form>

<script>
  var dataset = {};

  function createGejalaContainer(penyakitIndex) {
    var gejalaContainer = document.createElement('div');
    gejalaContainer.className = 'gejalaContainer';

    gejalaContainer.innerHTML = `
      <label for="gejala">Gejala:</label><br>
      <input type="text" name="gejala[${penyakitIndex}][]" required>
      <input type="number" name="nilai[${penyakitIndex}][]" step="0.1" min="0" max="1" required>
      <br><br>
    `;

    return gejalaContainer;
  }

  function addGejala(penyakitIndex) {
    var penyakitContainer = document.getElementsByClassName('penyakitContainer')[penyakitIndex];
    var gejalaContainer = penyakitContainer.getElementsByClassName('gejalaContainer')[0];
    var newGejalaContainer = createGejalaContainer(penyakitIndex);
    gejalaContainer.appendChild(newGejalaContainer);
  }

  document.getElementById('addPenyakit').addEventListener('click', function() {
    var penyakitContainer = document.createElement('div');
    penyakitContainer.className = 'penyakitContainer';

    penyakitContainer.innerHTML = `
      <label for="penyakit">Penyakit:</label>
      <input type="text" name="penyakit[]" required>
      <br><br>

      <div class="gejalaContainer">
        <label for="gejala">Gejala:</label><br>
        <input type="text" name="gejala[][${document.getElementsByClassName('penyakitContainer').length - 1}][]" required>
        <input type="number" name="nilai[][${document.getElementsByClassName('penyakitContainer').length - 1}][]" step="0.1" min="0" max="1" required>
        <br><br>
      </div>

      <button type="button" class="addGejala">Tambah Gejala</button>
      <br><br>
    `;

    penyakitContainer.querySelector('.addGejala').addEventListener('click', function() {
      var currentPenyakitIndex = Array.from(this.parentNode.parentNode.getElementsByClassName('addGejala')).indexOf(this);
      addGejala(currentPenyakitIndex);
    });

    document.getElementById('datasetContainer').appendChild(penyakitContainer);
  });

  document.getElementById('formDataset').addEventListener('submit', function(event) {
    event.preventDefault();
    var elem = document.getElementById('simpan');
    elem.style.display = 'inline';

    var penyakitInputs = document.getElementsByName('penyakit[]');
    var gejalaInputs = document.getElementsByName('gejala[]');
    var nilaiInputs = document.getElementsByName('nilai[]');

    // Mengumpulkan data penyakit dan gejala ke dalam dataset
    for (var i = 0; i < penyakitInputs.length; i++) {
      var penyakit = penyakitInputs[i].value;
      var gejalaContainers = penyakitInputs[i].parentNode.getElementsByClassName('gejalaContainer');
      dataset[penyakit] = {};

      for (var j = 0; j < gejalaContainers.length; j++) {
        var gejala = gejalaContainers[j].getElementsByTagName('input');
        var namaGejala = gejala[0].value;
        var nilaiGejala = parseFloat(gejala[1].value);

        dataset[penyakit][namaGejala] = nilaiGejala;
      }
    }

    console.log(dataset); // Tampilkan dataset di konsol (Anda dapat menggantinya dengan pemrosesan yang lain)

    // Kode sebelumnya...

    var outputContainer = document.getElementById('outputContainer');
    outputContainer.value = JSON.stringify(dataset, null, 2); // Menampilkan dataset dalam bentuk JSON dengan indentasi 2

    // Lakukan pengiriman data ke server atau tindakan lain yang Anda inginkan di sini
  });
</script>


</body>
</html>
