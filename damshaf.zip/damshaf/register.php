<?php
include("koneksi.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $nama = $_POST["nama"];
    $password = $_POST["password"];


    $sql = "INSERT INTO users VALUES ('','$nama','$username', '$password')";
    $result = $koneksi->query($sql);

    if ($result) {
        header("Location: index.php");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      background-color: #fafafa;
    }

    .login-container {
      max-width: 350px;
      margin: 0 auto;
      margin-top: 150px;
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
      background-color: #fff;
      box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
      margin-bottom: 30px;
    }

    .form-group input {
      border: none;
      border-bottom: 1px solid #ddd;
      border-radius: 0;
      padding: 10px;
      background-color: transparent;
      box-shadow: none;
      transition: border-color 0.3s ease-in-out;
    }

    .form-group input:focus {
      outline: none;
      border-color: #6c63ff;
    }

    .form-group input::placeholder {
      color: #999;
    }

    .login-button {
      padding: 10px 16px;
      font-size: 14px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="login-container">
      <h3 class="text-center">Daftar</h3>

      <form method="POST">
        <div class="form-group">
          <input type="text" class="form-control" name="nama" placeholder="Nama" required>
        </div>

        <div class="form-group">
          <input type="text" class="form-control" name="username" placeholder="Username" required>
        </div>

        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>

        <button type="submit" class="btn btn-primary btn-block login-button">Log In</button>
      </form>
      <hr>
      <p>Sudah punya akun? <a href="login.php">Login</a></p>
    </div>
  </div>
</body>
</html>
